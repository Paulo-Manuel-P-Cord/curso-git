n1=input("digite um número: ")
n2=input("digite um número: ")
soma= int(n1) + int(n2)
print(f"A soma desses número é: {soma}")