n1=int(input("digite um número: "))
n2=int(input("digite outro número: "))
soma=n1+n2 
sub=n1-n2
div=n1/n2
mult=n1*n2
print(f"a soma é: {soma}")
print(f"a subtração é: {sub}")
print(f"a multiplicação é: {mult}")
print(f"a divisão é: {div}")