nome=input("digite seu nome: ")
sobrenome=input("digite seu sobrenome: ")
print(f"{nome} {sobrenome}")
