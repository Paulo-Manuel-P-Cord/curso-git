n1=float(input("digite sua primeira nota: "))
n2=float(input("digite sua segunda nota: "))
media=(n1+n2)/2

if media>= 5.5 and media<= 5.9:
    print(f"você está aprovado e sua média é 6")
elif media>=6:
    print(f"você está aprovado e sua média é {media}")
else:
    print(f"você está reprovado e sua média é {media}")